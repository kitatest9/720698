export const character = {
    name: "Light Yagami",
    desc: "Justice is coming.",
    // Yahan aap jitni chahen images dal sakte hain
    thumbnails: [
        "https://image2url.com/r2/default/images/1771323364049-7056c018-5c98-47cf-b1a5-bc43b2e7e039.jpeg",
        "https://image2url.com/r2/default/images/1771323564652-2343a6e4-83b7-47e4-a167-9140e616a3c5.webp",
        "https://image2url.com/r2/default/images/1771323940695-32ac076e-0028-4169-a6b8-f116a5a325a4.webp",
        "https://image2url.com/r2/default/images/1771323984492-91f6c93d-9fa6-4ddd-adbb-7283de2252f7.webp"
        //"https://i.ibb.co"
    ],
    accentColor: "#FF0000" // Theme ka color code
};
