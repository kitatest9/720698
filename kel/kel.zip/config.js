export const config = {
    ownerName: "namelees",
    ownerNumber: "923073457436", // Sirf digits honi chahiye
    botName: "KEL",
    authorName: "nameles",
    prefix: [".", "!", "$"],
    mode: "public",
    activeTheme: "yagami"
};
